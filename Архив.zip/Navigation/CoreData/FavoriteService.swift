//
//  FavoriteService.swift
//  Navigation
//
//  Created by Никита  on 30.11.2023.
//

import Foundation
import CoreData

class FavoriteService{
  
    private let coreDataService:ICoreDataService = CoreDataService.shared
    //тут будет происходить сохранение в нашу кордату

    private (set) var toDoItems = [FavoriteBase]()

    
    
    private func fetch(completion: @escaping ([FavoriteBase]) -> Void) {
        coreDataService.backroundContext.perform { [weak self] in
            guard let self = self else { return }
            let request = FavoriteBase.fetchRequest()
            
            do {
                toDoItems = try self.coreDataService.backroundContext.fetch(request).map { $0 }
                self.coreDataService.mainContext.perform { [weak self] in
                    guard let self else { return }
                    completion(toDoItems)
                    
                }
                
            } catch {
                print(error)
                toDoItems = []
            completion(toDoItems)
            }
        }
    }
    
    func saveToDoItems(with author:String,comletion: @escaping ([FavoriteBase])->Void){
        coreDataService.backroundContext.perform { [weak self] in
            guard let self else {return}
            let favoriteBase = FavoriteBase(context: coreDataService.backroundContext)
            favoriteBase.author = author
            
            if coreDataService.backroundContext.hasChanges{
                do{
                    try coreDataService.backroundContext.save()
                    coreDataService.mainContext.perform { [weak self] in
                        guard let self else {return}
                        toDoItems.insert(contentsOf: toDoItems, at: 0)
                        comletion(toDoItems)
                    }
                }catch{
                    coreDataService.mainContext.perform{ [weak self] in
                        guard let self else {return}
                        comletion(toDoItems)
                    }
                }
            }
        }
    }
    
    func createItem(with autor:String, completion: @escaping([FavoriteBase])->Void){
        coreDataService.backroundContext.perform { [weak self] in
            guard let self else{return}
            let newItem = FavoriteBase(context: coreDataService.backroundContext)
            newItem.author = autor
            
            do{
                try coreDataService.backroundContext.save()
                coreDataService.mainContext.perform { [weak self] in
                    guard let self else {return}
                    toDoItems.insert(newItem, at: 0)
                    completion(toDoItems)
                }
            }catch{
                coreDataService.mainContext.perform { [weak self] in
                    guard let self else {return}
                    completion(toDoItems)
                }
            }
        }
    }

    func deleleItems(at index:Int, comletion: @escaping ([FavoriteBase])->Void){
        coreDataService.backroundContext.perform { [weak self] in
            guard let self else {return}
            coreDataService.backroundContext.delete(toDoItems[index])
            
            do{
                try coreDataService.backroundContext.save()
                coreDataService.mainContext.perform { [weak self] in
                    guard  let self else {return}
                    comletion(toDoItems)
                }
            }catch{
                coreDataService.mainContext.perform { [weak self] in
                    guard let self else {return}
                    comletion(toDoItems)
                }
            }
        }
    }
   
    // Метод для получения всех элементов (доступен извне)
    func getAllItems(completion: @escaping ([FavoriteBase]) -> Void) {
        fetch {_ in
            guard let self = self else { return }
            completion(self.toDoItems)
        }
    }

}
