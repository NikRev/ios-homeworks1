import UIKit
import iOSIntPackage

class PhotosViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    
    private let imagePublisherFacade = ImagePublisherFacade()
    
    private let collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumLineSpacing = 10
        layout.minimumInteritemSpacing = 10
        
        let numberOfColumns: CGFloat = 3
        let cellWidth = (UIScreen.main.bounds.width - (numberOfColumns - 1) * 10) / numberOfColumns
        layout.itemSize = CGSize(width: cellWidth, height: cellWidth)
        
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.backgroundColor = .white

        return collectionView
    }()
    
     var photoArray: [UIImage?] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let photo1 = UIImage(named: "photo1") {
            photoArray.append(photo1)
        }
        if let photo2 = UIImage(named: "photo2") {
        photoArray.append(photo2)
        }
        if let photo3 = UIImage(named: "photo3") {
            photoArray.append(photo3)
        }
        if let photo4 = UIImage(named: "photo4") {
                photoArray.append(photo4)
        }
               
        // Обновляется коллекцию после добавления изображений
        collectionView.reloadData()
        title = "Photo Gallery"
        view.addSubview(collectionView)
        
        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: view.topAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        
        // Скрываем NavigationBar при загрузке экрана
        navigationController?.setNavigationBarHidden(true, animated: false)
        
        // Зарегистрируйте PhotosViewController как подписчика на изменения
        imagePublisherFacade.subscribe(self)
        
        // Запуск сценария наполнения коллекции изображениями через метод addImagesWithTimer
        // С задержкой времени не менее 0.5 секунд и более  повторениями
        imagePublisherFacade.addImagesWithTimer(time: 0.5, repeat: 4)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return photoArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoCell", for: indexPath) as! PhotosCollectionViewCell
        let photo = photoArray[indexPath.item]
        cell.imageView.image = photo
        return cell
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // Показываем NavigationBar перед отображением экрана
        navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        // Скрываем NavigationBar при уходе с экрана и отменяем подписку
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
}

// Расширение для реализации метода receive(images:)
extension PhotosViewController: ImageLibrarySubscriber {
    func receive(images: [UIImage]) {
        // Обновляем коллекцию с новыми изображениями
        photoArray = images
        collectionView.reloadData()
    }
}
