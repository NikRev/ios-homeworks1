//
//  ViewController.swift
//  Navigation
//
//  Created by Никита  on 04.06.2023.
//

import UIKit

class ViewController: UIViewController {

   

      public override func viewDidLoad() {
           super.viewDidLoad()
           title = "Profile"
           
       }
       
       

}

