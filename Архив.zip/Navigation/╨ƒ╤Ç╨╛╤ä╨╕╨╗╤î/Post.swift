//
//  Post.swift
//  Navigation
//
//  Created by Никита  on 05.06.2023.
//

import Foundation
public struct Post1 {
   public var title:String
  
    public init(title: String) {
        self.title = title
    }

    
}

