import Foundation

class PublicationViewModel {
    var publication: Publications

    init(publication: Publications) {
        self.publication = publication
    }

   
}
